package com.example.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.entity.Blog;

@Repository
public interface BlogRepo extends JpaRepository<Blog, Integer>{
	
	Blog findByblogId(Integer id);

	Blog findByTitle(String title);

	void deleteByTitle(String title);

	List<Blog> findByUsername(String username);

}
