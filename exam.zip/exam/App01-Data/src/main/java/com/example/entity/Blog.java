package com.example.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "blog")
public class Blog {

	@Id
	@Column(name = "blogId")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer blogId;

	@Column(name = "title")
	private String title;
//
//	@Lob
//	@Column(name = "image")
//	private byte[] image;

	@Column(columnDefinition = "LONGTEXT", name = "description")
	private String description;

	@Column(name = "author")
	private String author;

	@Column(name = "username")
	private String username;

	public int getBlogId() {
		return blogId;
	}

	public void setBlogId(int blogId) {
		this.blogId = blogId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public void setBlogId(Integer blogId) {
		this.blogId = blogId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	@Override
	public String toString() {
		return "Blog [blogId=" + blogId + ", title=" + title + ", description=" + description + ", author=" + author
				+ ", username=" + username + "]";
	}

}
