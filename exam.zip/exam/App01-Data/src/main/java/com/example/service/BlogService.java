package com.example.service;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.entity.Blog;
import com.example.repo.BlogRepo;
import com.example.response.BlogResponse;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class BlogService {

	@Autowired
	BlogRepo repo;

	@Autowired
	ModelMapper mapper;

	public void addBlog(BlogResponse blogResponse) {
		Blog blog = mapper.map(blogResponse, Blog.class);
		System.out.println(blogResponse);
		repo.save(blog);
	}

	public BlogResponse getBlogByID(Integer id) {

		BlogResponse blogResponse = mapper.map(repo.findByblogId(id), BlogResponse.class);
		return blogResponse;
	}

	public void saveBlog(BlogResponse blogResponse) {
		Blog blog = mapper.map(blogResponse, Blog.class);
		repo.save(blog);
	}

	public ResponseEntity<List<BlogResponse>> getAllBlogs() {

		List<BlogResponse> blogResponse = mapper.map(repo.findAll(), new TypeToken<List<BlogResponse>>() {
		}.getType());
		return ResponseEntity.status(HttpStatus.OK).body(blogResponse);
	}

	public void updateByID(int id, BlogResponse blogResponse) {

		BlogResponse oldData = mapper.map(repo.findByblogId(id), BlogResponse.class);
		oldData.setTitle(blogResponse.getTitle());
		oldData.setAuthor(blogResponse.getAuthor());
		oldData.setDescription(blogResponse.getDescription());

		repo.save(mapper.map(oldData, Blog.class));

	}

	public BlogResponse getBlogByTitle(String title) {
		Blog blogs = repo.findByTitle(title);
		BlogResponse blogResponse = mapper.map(blogs, BlogResponse.class);
		return blogResponse;
	}

	public BlogResponse updateByTitle(String title, BlogResponse blogResponse) {
		BlogResponse oldData = mapper.map(repo.findByTitle(title), BlogResponse.class);

		oldData.setTitle(blogResponse.getTitle());
		oldData.setAuthor(blogResponse.getAuthor());
		oldData.setDescription(blogResponse.getDescription());

		return mapper.map(oldData, BlogResponse.class);
	}

	public boolean deletByTitle(String title) {
		if (repo.findByTitle(title) != null) {
			repo.deleteByTitle(title);
			return true;
		} else {
			return false;
		}
	}

	public ResponseEntity<List<BlogResponse>> getBlogsByUsername(String username) {
		List<BlogResponse> blogResponse = mapper.map(repo.findByUsername(username),
				new TypeToken<List<BlogResponse>>() {
				}.getType());
		return ResponseEntity.status(HttpStatus.OK).body(blogResponse);
	}
}
