package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class App01DataApplication {

	public static void main(String[] args) {
		SpringApplication.run(App01DataApplication.class, args);
	}

}
