package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.response.BlogResponse;
import com.example.service.BlogService;

@RestController
@RequestMapping("blog/api")
public class BlogController {

	@Autowired
	BlogService service;

	@GetMapping("blogs/{id}")
	public BlogResponse getById(@PathVariable Integer id) {
		return service.getBlogByID(id);
	}

	@PostMapping("/addBlog")
	public ResponseEntity<BlogResponse> addBlog(@RequestBody BlogResponse blogResponse) {
		service.addBlog(blogResponse);
		return new ResponseEntity<BlogResponse>(blogResponse, HttpStatus.CREATED);
	}

	@GetMapping("/blogs")
	public ResponseEntity<List<BlogResponse>> getAllBlogs() {
		return service.getAllBlogs();
	}
	
	@GetMapping("/blogs/username/{username}")
	public ResponseEntity<List<BlogResponse>> getAllBlogsByUsername(@PathVariable String username) {
		return service.getBlogsByUsername(username);
	}

	@PutMapping("/blogs/update/{id}")
	public ResponseEntity<BlogResponse> updateBlog(@PathVariable int id, @RequestBody BlogResponse blogResponse)
			throws Exception {

		if (blogResponse == null)
			return new ResponseEntity<BlogResponse>(HttpStatus.NOT_FOUND);
		else {

			if (service.getBlogByID(id) == null) {
				throw new Exception("Data Not Found");
			} else {
				service.updateByID(id, blogResponse);
			}

			return new ResponseEntity<BlogResponse>(HttpStatus.OK);
		}

	}

	@GetMapping("/blogs/title/{title}")
	public BlogResponse getBlogByTitle(@PathVariable String title) {
		return service.getBlogByTitle(title);

	}

	@GetMapping("/blogs/updateByTitle/{title}")
	public BlogResponse updateByTitle(@PathVariable String title, BlogResponse blogResponse) {
		return service.updateByTitle(title, blogResponse);
	}

	@DeleteMapping("/blogs/deleteByTitle/{title}")
	public ResponseEntity<?> deleteByTitle(@PathVariable String title) {
		boolean isDeleted = service.deletByTitle(title);

		if (isDeleted) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		} else {
			return new ResponseEntity<>("Blog not found", HttpStatus.NOT_FOUND); 
		}
	}

}
