package com.example.feignclient;

import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name = "App01-data", url = "http://localhost:8082", path = "/blog/api")
public interface BlogClient {

}
