package com.example.feignClient;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.response.CommentResponse;

@FeignClient(name = "App01-webComment", url = "http://localhost:8083", path = "/comment/api")
public interface CommentClient {

	@PostMapping("/addComment/")
	public ResponseEntity<CommentResponse> addComment(CommentResponse comment);

	@GetMapping("/allComments")
	public ResponseEntity<List<CommentResponse>> getAllComments();

	@DeleteMapping("/deleteComment/{id}")
	public ResponseEntity<?> deleteById(@PathVariable int id);

	@GetMapping("/comment/{id}")
	public ResponseEntity<CommentResponse> getCommentById(@PathVariable int id);
}
