package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.feignClient.CommentClient;
import com.example.response.CommentResponse;

@Service
public class CommentService {

	@Autowired
	CommentClient client;

	public void addComment(CommentResponse commentResponse) {
		client.addComment(commentResponse);
	}
	
	public List<CommentResponse> getAllComments() {
		return client.getAllComments().getBody();
	}

	public void deleteComment(int commentId) {
		 client.deleteById(commentId);
	}

	public void editComment(int commentId, String Comment) {
		CommentResponse oldComment = client.getCommentById(commentId).getBody();
		CommentResponse newComment = new CommentResponse(oldComment.getTitle(), Comment, oldComment.getUsername());
		client.deleteById(commentId);
		client.addComment(newComment);

	}
}
