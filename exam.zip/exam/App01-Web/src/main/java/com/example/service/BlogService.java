package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.feignClient.BlogClient;
import com.example.response.BlogResponse;

@Service
public class BlogService {

	@Autowired
	BlogClient client;

	public BlogResponse getByID(Integer id) {
		return client.getById(id);
	}

	public void saveBlog(BlogResponse blog) {
		client.addBlog(blog);
	}

	public List<BlogResponse> getAllBlogs() {
		return client.getAllBlogs().getBody();
	}

	public BlogResponse getBlogByTitle(String title) {
		return client.getBlogByTitle(title);
	}

	public void updateBlog(BlogResponse updatedBlog) {
		client.addBlog(updatedBlog);

	}

	public void deleteByTitle(String title) {
		client.deleteByTitle(title);
	}
	
	public List<BlogResponse> getAllBlogsByUsername(String username) {
		return client.getAllBlogsByUsername(username).getBody();
	}
	

}
