package com.example.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.response.CommentResponse;
import com.example.service.CommentService;
import com.example.service.SecurityService;

@RequestMapping("blog/api")
@Controller
public class CommentController {
	
	@Autowired
	CommentService service;
	
	@Autowired
	SecurityService securityService;
	
	@PostMapping("/addComment")
	public ModelAndView addComment(@RequestParam String comment,
							@RequestParam String blogTitle) {
		
		ModelAndView model = new ModelAndView("message");
		try {
			service.addComment(new CommentResponse(blogTitle, comment, securityService.getUserName()));
			model.addObject("message", "Comment Uploaded");
		}catch (Exception e) {
			model.addObject("message","Comment failed to upload!!");
		}
		
		return model;
	}
	
	@PostMapping("/editComment")
	public ModelAndView editComment(@RequestParam int commentId, @RequestParam String newComment) {
	    ModelAndView model = new ModelAndView();
	    
	    try {
	        service.editComment(commentId, newComment);
	        model.addObject("message", "Comment edited successfully.");
	    } catch (Exception e) {
	        model.addObject("message", "Error editing comment: " + e.getMessage());
	    }
	    
//	    model.setViewName("redirect:/blogDetails?title=" + blogTitle);
	    model.setViewName("message");
	    
	    return model;
	    
	}


	@PostMapping("/deleteComment")
	public ModelAndView deleteComment(@RequestParam int commentId,
										@RequestParam String blogTitle) {
	    ModelAndView model = new ModelAndView();
	    
	    try {
	        service.deleteComment(commentId);
	        model.addObject("message", "Comment deleted successfully.");
	    } catch (Exception e) {
	        model.addObject("message", "Error deleting comment: " + e.getMessage());
	    }
	    
//	    model.setViewName("redirect:/blogDetails?title=" + blogTitle);
	    model.setViewName("message");
	    
	    return model;
	}

}
