package com.example.feignClient;

public interface UserClient {

}
