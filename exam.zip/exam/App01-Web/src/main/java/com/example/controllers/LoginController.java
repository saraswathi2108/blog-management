package com.example.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.entity.UserData;
import com.example.service.UserDataService;

@Controller
public class LoginController {

	@Autowired
	UserDataService service;
	
	@GetMapping("/")
	public String index() {
		return "redirect:/blog/api/";
	}

	@GetMapping("/login")
	public String customLogin() {
		return "login";
	}

	@PostMapping("/loginAction")
	public String move() {
		return index();
	}

	@PostMapping("/blog/api/logout")
	public String logout() {
		return "redirect:/login";
	}


	@GetMapping("/signup")
	public String signup(Model model) {
		model.addAttribute("userData", new UserData());

		return "signup";
	}

	@PostMapping("/signupAction")
	public String signUpAction(@ModelAttribute UserData userData) {
		service.addUser(userData);
		return "redirect:/";

	}
	
	@GetMapping("/error")
	public String error() {
		return index();
	}

}