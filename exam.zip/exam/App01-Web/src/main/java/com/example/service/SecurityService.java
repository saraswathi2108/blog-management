package com.example.service;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import com.example.entity.UserData;
import com.example.repo.UserDataRepo;

@Service
public class SecurityService {
	
	@Autowired UserDataRepo repo;

	public String getUserName() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if (authentication != null && authentication.isAuthenticated()) {
			Object principal = authentication.getPrincipal();
			String username;
			if (principal instanceof UserDetails) {
				username = ((UserDetails) principal).getUsername();
			} else {
				username = principal.toString();
			}
			return username.substring(0,1).toUpperCase() + username.substring(1, username.length()-10);
		}
		return "User";
	}
	
	public String getRole() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null && authentication.isAuthenticated()) {
            Collection<? extends GrantedAuthority> authorities = authentication.getAuthorities();
            for (GrantedAuthority authority : authorities) {
                return authority.getAuthority(); 
            }
        }
        return "ROLE_USER"; 
    }

	public UserData findByUsername(String username) {
		return repo.findByEmail(username+"@gmail.com");
	}

}	
