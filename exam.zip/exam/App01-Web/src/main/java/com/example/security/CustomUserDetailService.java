package com.example.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.example.entity.UserData;
import com.example.repo.UserDataRepo;

@Service
public class CustomUserDetailService implements UserDetailsService {

	@Autowired
	UserDataRepo repo;
	
	@Override
	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
		UserData data = repo.findByEmail(email);
		
		if (data == null) {
			throw new UsernameNotFoundException("User not found");
		}

 		
		return new CustomUserDetails(data);
	}

}
