package com.example.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.entity.UserData;

@Repository
public interface UserDataRepo extends JpaRepository<UserData, String>{
	
	UserData findByEmail(String email);

}
