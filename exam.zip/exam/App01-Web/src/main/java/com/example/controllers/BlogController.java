package com.example.controllers;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.response.BlogResponse;
import com.example.response.CommentResponse;
import com.example.service.BlogService;
import com.example.service.CommentService;
import com.example.service.SecurityService;

@RequestMapping("blog/api")
@Controller
public class BlogController {

	@Autowired BlogService service;
	
	@Autowired CommentService commentService;
	
	@Autowired SecurityService securityService;
	
	@GetMapping("/")
	public ModelAndView home() {
		ModelAndView model = new ModelAndView();
		model.addObject("username", securityService.getUserName());
		model.addObject("role", securityService.getRole());
		List<BlogResponse> blogs = service.getAllBlogs();
		model.addObject("blogs", blogs);
		model.setViewName("home");

		return model;
	}
	

	@GetMapping("/blogDetails")
	public String blogDetails(@RequestParam String title, Model model) {
		model.addAttribute("username", securityService.getUserName());
		BlogResponse blog = service.getBlogByTitle(title.trim());
		List<CommentResponse> comments = commentService.getAllComments();
		if (blog != null) {
			model.addAttribute("blog", blog);
			model.addAttribute("comments", comments);
			return "blogDetails";
		} else {
			return "redirect:/";
		}
	}

	@GetMapping("/home")
	public ModelAndView index() {
		return home();
	}

	@GetMapping("/viewBlogs")
	public String viewBlogs(Model model) {
		return "viewBlogs";
	}

	@GetMapping("/addBlog")
	public String addBlog(Model model) {
		model.addAttribute("username", securityService.getUserName());
		return "addBlog";
	}

	@PostMapping("/saveBlog")
	public ModelAndView saveBlog(@RequestParam String title,
//	                       @RequestParam MultipartFile image,
			@RequestParam String author, @RequestParam String description, ModelAndView model) throws IOException {

//	    	byte[] imageValue =  image.getBytes();
		// System.out.println(imageValue);
		model.addObject("username", securityService.getUserName());
		BlogResponse blogResponse = new BlogResponse(title.trim(), description.trim(), author.trim(), securityService.getUserName());
//    	System.out.println(blogResponse);
		service.saveBlog(blogResponse);
		model.addObject("message", "Post Uploaded");
		model.setViewName("message");
		return model;
	}

	@GetMapping("/{id}")
	public ModelAndView getBlog(@PathVariable Integer id) {
		ModelAndView model = new ModelAndView();
		model.addObject("username", securityService.getUserName());
		model.addObject("blog", service.getByID(id));
		model.setViewName("blog");
		return model;
	}

	@GetMapping("/update")
	public String update(Model model) {
		model.addAttribute("username", securityService.getUserName());
		return "update";
	}

	@GetMapping("/updateByTitle")
	public ModelAndView updateByTitle(@RequestParam String title) {
		ModelAndView model = new ModelAndView();
		model.addObject("username", securityService.getUserName());

		try {
			BlogResponse blog = service.getBlogByTitle(title.trim());
			if (securityService.getUserName().equals(blog.getUsername())) {
				model.addObject("blog", blog);
				model.setViewName("updateAction");
				service.deleteByTitle(title.trim());
			} else {
				model.addObject("message", "You can't update this blog");
				model.setViewName("message");
			}
		} catch (Exception e) {
			model.addObject("message", "No blog found with the given Title");
			model.setViewName("message");
		}

		return model;
	}

	@PostMapping("/updateBlog")
	public ModelAndView updateBlog(@RequestParam String title, @RequestParam String author,
			@RequestParam String description) {
		BlogResponse updatedBlog = new BlogResponse(title.trim(), description.trim(), author.trim());
		ModelAndView model = new ModelAndView();
			service.updateBlog(updatedBlog);
			model.addObject("username", securityService.getUserName());
			model.addObject("message", "Blog updated successfully");
			model.setViewName("message");
		
		
		return model;
	}

	@GetMapping("/delete")
	public String deleteBlog(Model model) {
		model.addAttribute("username", securityService.getUserName());
		return "delete";
	}

	@GetMapping("/deleteByTitle")
	public ModelAndView deleteByTitle(@RequestParam String title) {
		ModelAndView model = new ModelAndView();
//		System.out.println(title);

		try {
			BlogResponse blog = service.getBlogByTitle(title);
			if (securityService.getUserName().equals(blog.getUsername())) {
				service.deleteByTitle(title.trim());
				model.addObject("message", "Blog deleted successfully");
				model.setViewName("message");
				return model;
			}
			else {
				model.addObject("message", "You can't delete this blog");
				model.setViewName("message");
			}
		} catch (Exception e) {
			model.addObject("message", "No blog found with the given Title");
			model.setViewName("message");
		}

		return model;
	}

	@GetMapping("/search")
	public ModelAndView searchBlogByTitle(@RequestParam String title, ModelAndView model) {
		try {
			BlogResponse blog = service.getBlogByTitle(title.trim());
			model.addObject("blog", blog);
			model.setViewName("blogDetails");
			model.addObject("username", securityService.getUserName());
			List<CommentResponse> comments = commentService.getAllComments();
			model.addObject("comments", comments);

		} catch (Exception e) {
			model.addObject("message", "Blog not found");
			model.setViewName("message");
		}
		return model;
	}
	
	@GetMapping("/deleteByAdmin")
	public ModelAndView deleteByAdmin(@RequestParam String title){
//		service.deleteByTitle((String)request.getAttribute("title"));
		service.deleteByTitle(title.trim());
		return home();
	}

	@GetMapping("/myblogs")
	public String getMyBlogs(Model model) {
		model.addAttribute("username", securityService.getUserName());
	    List<BlogResponse> myBlogs = service.getAllBlogsByUsername(securityService.getUserName());
	    model.addAttribute("myBlogs", myBlogs);
	    return "myBlogs";
	}

}
