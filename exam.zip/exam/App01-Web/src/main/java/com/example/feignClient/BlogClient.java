package com.example.feignClient;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.response.BlogResponse;

@FeignClient(name = "App01-webBlog", url = "http://localhost:8082", path = "/blog/api")
public interface BlogClient {
	
	@GetMapping("blogs/{id}")
	public BlogResponse getById(@PathVariable Integer id);
	
	@PostMapping("/addBlog")
	public void addBlog(BlogResponse blogResponse);
	
	@GetMapping("/blogs")
	public ResponseEntity<List<BlogResponse>> getAllBlogs();
	
	@GetMapping("/blogs/title/{title}")
	public BlogResponse getBlogByTitle(@PathVariable String title);

	@GetMapping("/blogs/updateByTitle/{title}")
	public BlogResponse updateByTitle(@PathVariable String title, BlogResponse blogResponse);
	
	
	@DeleteMapping("/blogs/deleteByTitle/{title}")
	public ResponseEntity<?> deleteByTitle(@PathVariable String title);

	@GetMapping("/blogs/username/{username}")
	public ResponseEntity<List<BlogResponse>> getAllBlogsByUsername(@PathVariable String username);

	
}
