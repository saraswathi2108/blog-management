package com.example.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.example.entity.UserData;
import com.example.service.SecurityService;

@RequestMapping("blog/api")
@Controller
public class ProfileController {
	
	@Autowired SecurityService securityService;

	@GetMapping("/profile")
	public ModelAndView viewProfile() {
	    ModelAndView model = new ModelAndView("profile"); 
		model.addObject("username", securityService.getUserName());
	    String username = securityService.getUserName(); 
	    UserData user = securityService.findByUsername(username); 

	    model.addObject("user", user);
	    return model;
	}

}
