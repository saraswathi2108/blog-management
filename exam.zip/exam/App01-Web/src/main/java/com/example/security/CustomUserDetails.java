package com.example.security;

import java.util.Collection;
import java.util.Collections;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.example.entity.UserData;

public class CustomUserDetails implements UserDetails {
	
	private String email;
	private String password;
	private List<GrantedAuthority> authorities;
	private String profession;
	
	
	public CustomUserDetails(UserData userdata) {
		this.email = userdata.getEmail();
		this.password = userdata.getConfirmPassword();
		this.profession = userdata.getProfession();
		if(!profession.equals("ADMIN"))
			this.authorities = Collections.singletonList(new SimpleGrantedAuthority("USER"));
		else
			this.authorities = Collections.singletonList(new SimpleGrantedAuthority("ADMIN"));
	}


	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return authorities;
	}

	@Override
	public String getPassword() {
		return password;
	}

	@Override
	public String getUsername() {
		return email;
	}

}
