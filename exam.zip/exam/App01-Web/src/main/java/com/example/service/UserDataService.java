package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.entity.UserData;
import com.example.repo.UserDataRepo;

@Service
public class UserDataService {

	@Autowired
	UserDataRepo repo;

	@Autowired
	PasswordEncoder encoder;

	public void addUser(UserData userData) {
		userData.setPassword(encoder.encode(userData.getPassword()));
		userData.setConfirmPassword(encoder.encode(userData.getConfirmPassword()));
		repo.save(userData);
	}
}
