package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class App01Data2Application {

	public static void main(String[] args) {
		SpringApplication.run(App01Data2Application.class, args);
	}

}
