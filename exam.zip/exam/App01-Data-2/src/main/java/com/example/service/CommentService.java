package com.example.service;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.entity.Comment;
import com.example.repo.CommentRepo;
import com.example.response.CommentResponse;

@Service
public class CommentService {

	@Autowired
	CommentRepo repo;
	
	@Autowired
	ModelMapper mapper;
	
	public void addComment(CommentResponse comment) {
		repo.save(mapper.map(comment, Comment.class));
	}

	public ResponseEntity<List<CommentResponse>> getAllComments() {
		List<CommentResponse> responseEntity = mapper.map(repo.findAll(), new TypeToken<List<CommentResponse>>() {}.getType());
		return ResponseEntity.status(HttpStatus.OK).body(responseEntity);
	}


	public void deletById(int id) {
		repo.deleteById(id);;
	}

	public ResponseEntity<CommentResponse> getCommentById(int id) {
		CommentResponse commentResponse = mapper.map(repo.getById(id), CommentResponse.class);
		return ResponseEntity.status(HttpStatus.OK).body(commentResponse);
	}

}
