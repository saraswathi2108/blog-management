package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.response.CommentResponse;
import com.example.service.CommentService;

@RestController
@RequestMapping("comment/api")
public class CommentController {
	
	@Autowired
	CommentService service;
	
	@PostMapping("/addComment/")
	public ResponseEntity<CommentResponse> addComment(@RequestBody CommentResponse comment){
		service.addComment(comment);
		
		return new ResponseEntity<CommentResponse>(comment, HttpStatus.CREATED);
	}

	@GetMapping("/allComments")
	public ResponseEntity<List<CommentResponse>> getAllComments(){
		return service.getAllComments();
	}
	
	@GetMapping("/comment/{id}")
	public ResponseEntity<CommentResponse> getCommentById(@PathVariable int id){
		return service.getCommentById(id);
	}
	
	@DeleteMapping("/deleteComment/{id}")
	public ResponseEntity<?> deleteByTitle(@PathVariable int id) {
		try {
			service.deletById(id);
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}catch(Exception e) {
			return new ResponseEntity<>("Blog not found", HttpStatus.NOT_FOUND); 
		}
	}
	
}
