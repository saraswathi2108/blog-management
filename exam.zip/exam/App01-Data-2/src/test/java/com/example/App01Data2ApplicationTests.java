package com.example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class App01Data2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
